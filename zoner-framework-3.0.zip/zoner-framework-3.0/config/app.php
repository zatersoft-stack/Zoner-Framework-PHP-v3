<?php
return [
    'name'     => 'Zoner Framework',
    'version'  => '3.0.0',
    'env'      => 'local',
    'debug'    => true,
    'timezone' => 'America/Sao_Paulo',
];
