<?php

use Zoner\Router;

/**
 * Registra as rotas da aplicação.
 *
 * @param Router $router
 * @return void
 */
return function (Router $router): void {
    // Rota padrão
    $router->get('/', 'HomeController@index');

    // Exemplo de rota adicional
    $router->get('/sobre', 'HomeController@sobre');
};
