// Zoner Framework 3.0 - JS padrão
document.addEventListener('DOMContentLoaded', () => {
    console.log('Zoner Framework 3.0 inicializado.');
});
