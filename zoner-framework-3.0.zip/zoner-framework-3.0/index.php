<?php
declare(strict_types=1);

use Zoner\Zoner;
use Zoner\Router;

// Definir o caminho base
define('BASE_PATH', __DIR__);
define('APP_PATH', BASE_PATH . '/app');
define('CONFIG_PATH', BASE_PATH . '/config');
define('TEMPLATE_PATH', BASE_PATH . '/template');
define('SHARED_PATH', BASE_PATH . '/shared');
define('PUBLIC_PATH', BASE_PATH . '/public');

// Autoload simples do Zoner
require BASE_PATH . '/zoner/Autoload.php';

// Carrega configurações
$appConfig = require CONFIG_PATH . '/app.php';
$routesConfig = require CONFIG_PATH . '/routes.php';

// Inicializa o núcleo do framework
$zoner = new Zoner($appConfig);

// Registra rotas
$router = new Router();
$routesConfig($router);

// Processa a requisição atual
$zoner->handle($router);
