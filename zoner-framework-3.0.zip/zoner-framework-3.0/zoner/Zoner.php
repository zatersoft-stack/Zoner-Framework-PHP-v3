<?php
namespace Zoner;

class Zoner
{
    protected array $config;

    public function __construct(array $config = [])
    {
        $this->config = $config;

        date_default_timezone_set($config['timezone'] ?? 'UTC');

        if (($config['debug'] ?? false) === true) {
            ini_set('display_errors', '1');
            error_reporting(E_ALL);
        } else {
            ini_set('display_errors', '0');
        }
    }

    public function handle(Router $router): void
    {
        $request  = new Request();
        $response = new Response();

        try {
            [$controllerClass, $method] = $router->resolve($request->getMethod(), $request->getPath());

            if (!class_exists($controllerClass)) {
                throw new \RuntimeException("Controller não encontrado: {$controllerClass}");
            }

            $controller = new $controllerClass($request, $response);

            if (!method_exists($controller, $method)) {
                throw new \RuntimeException("Método {$method} não encontrado no controller {$controllerClass}");
            }

            $result = $controller->{$method}();

            if ($result instanceof Response) {
                $result->send();
            } elseif (is_string($result)) {
                $response->setBody($result)->send();
            } else {
                $response->json($result)->send();
            }
        } catch (\Throwable $e) {
            if (($this->config['debug'] ?? false) === true) {
                $response->setStatusCode(500)->setBody(
                    "<h1>Erro no Zoner Framework</h1><pre>{$e}</pre>"
                )->send();
            } else {
                $response->setStatusCode(500)->setBody(
                    "<h1>Erro interno</h1><p>Tente novamente mais tarde.</p>"
                )->send();
            }
        }
    }
}
