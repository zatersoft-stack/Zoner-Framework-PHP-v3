<?php
namespace Zoner;

spl_autoload_register(function ($class) {
    $prefixes = [
        'Zoner\\' => __DIR__,
        'App\\'   => BASE_PATH . '/app',
    ];

    foreach ($prefixes as $prefix => $baseDir) {
        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0) {
            continue;
        }

        $relativeClass = substr($class, $len);
        $file = $baseDir . '/' . str_replace('\\', '/', $relativeClass) . '.php';

        if (file_exists($file)) {
            require $file;
            return;
        }
    }
});

// Carrega helpers globais
$helpers = BASE_PATH . '/app/Helpers/helpers.php';
if (file_exists($helpers)) {
    require $helpers;
}
