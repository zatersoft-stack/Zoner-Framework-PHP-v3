<?php
namespace Zoner;

class Router
{
    protected array $routes = [];

    public function get(string $path, string $handler): self
    {
        return $this->addRoute('GET', $path, $handler);
    }

    public function post(string $path, string $handler): self
    {
        return $this->addRoute('POST', $path, $handler);
    }

    public function addRoute(string $method, string $path, string $handler): self
    {
        $this->routes[$method][$path] = $handler;
        return $this;
    }

    public function resolve(string $method, string $path): array
    {
        $path = rtrim($path, '/') ?: '/';

        $handler = $this->routes[$method][$path] ?? null;

        if (!$handler) {
            throw new \RuntimeException("Rota não encontrada: {$method} {$path}");
        }

        if (strpos($handler, '@') === false) {
            throw new \RuntimeException("Handler inválido para rota {$path}. Use Controller@metodo.");
        }

        [$controller, $action] = explode('@', $handler);
        $controllerClass = "App\\Controllers\\{$controller}";

        return [$controllerClass, $action];
    }
}
