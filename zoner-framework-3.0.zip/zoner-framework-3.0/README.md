# Zoner Framework 3.0

Micro framework em PHP desenvolvido pela **ZaterSoft**.  
Engenheiro responsável: **Melquisedeque C. Campos**.

## Requisitos

- PHP >= 8.1
- Extensões padrão do PHP
- Composer (opcional, para autoload futuro)

## Estrutura do Projeto

```text
app/         # Controllers, Models, Services, Middlewares, Helpers
config/      # Configurações da aplicação, banco e rotas
public/      # Assets públicos (CSS, JS, imagens)
shared/      # Partes fatiadas de layout (header, footer, menu, componentes)
template/    # Views (.phtml)
plugins/     # Plugins oficiais ou de terceiros
zoner/       # Núcleo do framework (Router, Request, Response, Zoner core)
storage/     # Logs, cache, sessões
index.php    # Front controller principal
router.php   # Router para servidor embutido do PHP
README.md
```

## Rodando com o servidor embutido do PHP

No diretório raiz do projeto, execute:

```bash
php -S localhost:8000 router.php
```

Depois acesse:

```text
http://localhost:8000/
```

Você verá a tela inicial do **Zoner Framework 3.0** com o template padrão.

## Rotas

As rotas são registradas no arquivo:

```text
config/routes.php
```

Exemplo:

```php
$router->get('/', 'HomeController@index');
$router->get('/sobre', 'HomeController@sobre');
```

O controlador correspondente fica em `app/Controllers/HomeController.php`.

## Controllers

Exemplo de Controller:

```php
namespace App\Controllers;

use Zoner\Request;
use Zoner\Response;

class HomeController
{
    public function __construct(Request $request, Response $response) { /* ... */ }

    public function index(): Response
    {
        $html = view('home/index', ['title' => 'Zoner Framework 3.0']);
        return $response->setBody($html);
    }
}
```

## Views

As views ficam em `template/`.  
O layout principal está em:

```text
template/layout.phtml
```

Exemplo de view:

```text
template/home/index.phtml
```

## Helpers

Helpers globais ficam em:

```text
app/Helpers/helpers.php
```

Já existe um helper `view()` para renderizar views dentro do layout.

## Plugins

Plugins ficam em:

```text
plugins/
```

Cada plugin pode ter sua própria estrutura (config, rotas, controllers, views).  
Exemplo de plugin de formulários em `plugins/forms`.

## Créditos

- Framework: **Zoner Framework 3.0**
- Desenvolvido por: **ZaterSoft**
- Engenheiro: **Melquisedeque C. Campos**
```
