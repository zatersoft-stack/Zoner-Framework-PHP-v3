<?php

if (!function_exists('view')) {
    /**
     * Renderiza um template PHTML dentro do layout padrão.
     *
     * @param string $template Caminho relativo em template/ (ex: 'home/index')
     * @param array  $data Variáveis para a view
     */
    function view(string $template, array $data = []): string
    {
        $layoutPath   = TEMPLATE_PATH . '/layout.phtml';
        $templatePath = TEMPLATE_PATH . '/' . $template . '.phtml';

        if (!file_exists($templatePath)) {
            throw new RuntimeException("View não encontrada: {$templatePath}");
        }

        extract($data);

        // Captura o conteúdo da view
        ob_start();
        include $templatePath;
        $content = ob_get_clean();

        // Agora injeta no layout
        ob_start();
        include $layoutPath;
        return ob_get_clean();
    }
}
