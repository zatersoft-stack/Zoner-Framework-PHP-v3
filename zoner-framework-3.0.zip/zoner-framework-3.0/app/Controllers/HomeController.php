<?php
namespace App\Controllers;

use Zoner\Request;
use Zoner\Response;

class HomeController
{
    protected Request $request;
    protected Response $response;

    public function __construct(Request $request, Response $response)
    {
        $this->request  = $request;
        $this->response = $response;
    }

    public function index(): Response
    {
        $html = view('home/index', [
            'title' => 'Zoner Framework 3.0',
        ]);

        return $this->response->setBody($html);
    }

    public function sobre(): Response
    {
        $html = view('home/sobre', [
            'title' => 'Sobre o Zoner Framework',
        ]);

        return $this->response->setBody($html);
    }
}
