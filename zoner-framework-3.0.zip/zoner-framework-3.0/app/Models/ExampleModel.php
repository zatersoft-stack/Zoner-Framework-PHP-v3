<?php
namespace App\Models;

class ExampleModel
{
    public function hello(): string
    {
        return 'Este é um exemplo de Model no Zoner Framework 3.0.';
    }
}
