<?php
namespace App\Middlewares;

class AuthMiddleware
{
    public function handle(): void
    {
        // Exemplo de middleware (futuro)
    }
}
