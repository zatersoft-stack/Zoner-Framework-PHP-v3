<?php
namespace App\Services;

class ExampleService
{
    public function doSomething(): string
    {
        return 'Serviço de exemplo executado.';
    }
}
