<?php
return [
    'name'        => 'Forms Plugin',
    'description' => 'Exemplo de plugin para formulários no Zoner Framework.',
    'version'     => '1.0.0',
];
