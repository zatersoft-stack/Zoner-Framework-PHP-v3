<?php
// Zoner Framework 3.0 - Router para servidor embutido do PHP
//
// Rode assim na raiz do projeto:
//   php -S localhost:8000 router.php
//
// Este arquivo entrega tudo o que estiver em /public (CSS, JS, imagens, etc)
// e passa o resto para o index.php (front controller).

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Caminho físico do arquivo dentro da pasta public
$publicPath = __DIR__ . '/public' . $uri;

// Se for um arquivo que existe em /public, devolve esse arquivo
if ($uri !== '/' && file_exists($publicPath) && !is_dir($publicPath)) {
    // Detecta tipo básico de conteúdo (só pra ficar bonitinho)
    $ext = pathinfo($publicPath, PATHINFO_EXTENSION);
    $mime = match ($ext) {
        'css'  => 'text/css',
        'js'   => 'application/javascript',
        'png'  => 'image/png',
        'jpg', 'jpeg' => 'image/jpeg',
        'gif'  => 'image/gif',
        'svg'  => 'image/svg+xml',
        'ico'  => 'image/x-icon',
        default => 'application/octet-stream',
    };

    header("Content-Type: {$mime}");
    readfile($publicPath);
    exit;
}

// Qualquer outra coisa vai pro index.php
require __DIR__ . '/index.php';
